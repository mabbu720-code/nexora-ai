// Free server (Vercel Hobby). Keeps your Gemini API key secret on the server.
// Set environment variable GEMINI_API_KEY in Vercel project settings.
// Optional: GEMINI_MODEL (default below).
module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (!process.env.GEMINI_API_KEY) return res.status(500).json({ error: "Server API key is not set" });
  const { system, messages } = req.body || {};
  if (!Array.isArray(messages) || !messages.length) return res.status(400).json({ error: "No messages" });
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent", {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: String(system || "").slice(0, 2000) }] },
        contents: messages.slice(-12).map(m => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: String(m.content).slice(0, 4000) }]
        })),
        generationConfig: { maxOutputTokens: 1024 }
      })
    });
    const d = await r.json();
    if (!r.ok) {
      const msg = r.status === 429 ? "Too many requests right now. Please try again in a minute." : (d.error && d.error.message) || "API error";
      return res.status(r.status).json({ error: msg });
    }
    const parts = d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts;
    res.status(200).json({ text: (parts || []).map(p => p.text || "").join("") });
  } catch (e) {
    res.status(500).json({ error: "Server error" });
  }
};
